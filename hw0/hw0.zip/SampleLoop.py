# Print 0 through 9
i = 0
while i < 10:
	print(i)
	i += 1

# Infinite Loop!
i = 0
while i < 10:
	print(i)
i += 1
